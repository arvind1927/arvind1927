from django.apps import AppConfig


class UserincomeConfig(AppConfig):
    name = 'userincome'
