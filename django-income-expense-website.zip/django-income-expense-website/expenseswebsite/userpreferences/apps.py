from django.apps import AppConfig


class UserpreferencesConfig(AppConfig):
    name = 'userpreferences'
